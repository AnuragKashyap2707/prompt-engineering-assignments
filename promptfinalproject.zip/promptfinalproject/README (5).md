# EduGen — All‑in‑One RAG Educational Content Generator (MAX Edition)

> Single‑notebook project that turns PDFs into **lessons, quizzes, summaries, and flashcards** using **Prompt Engineering** + **Retrieval‑Augmented Generation** (sparse, vector, and hybrid), a small **multimodal** visualization, **static web export**, and **quantitative retrieval metrics**.

## 🎯 What this repository contains
- `EduGen_All_in_One_MAX_RAG_UI_FULL (3).ipynb` — the entire project in one notebook
- `pdfs/` — your source documents (add at least 1–2 PDFs to demo)
- `outputs/` — generated artifacts (architecture diagram, concept map, devset, metrics, etc.)
- `web/` — static page export (HTML + assets) suitable for GitHub Pages
- `tests/` — tiny tests for export artifacts and guardrails
- `requirements.txt` — Python dependencies

## ✅ Core rubric coverage
- **Prompt Engineering:** system + output templates; structured generation flows
- **RAG:** TF‑IDF/BM25 (sparse) + Sentence‑Transformers + FAISS (vector) + **hybrid** combiner (tunable α)
- **Multimodal:** auto‑generated **concept map** from retrieved context (NetworkX + matplotlib)
- **Synthetic Data:** small devset builder to evaluate retrieval
- **Evaluation:** **Hit@1/3/5** and **MRR**, saved to JSON and rendered on the web page
- **Web Page:** static export with latest output + visuals + metrics
- **Testing scripts:** minimal tests for export/guardrails

> Fine‑tuning is optional; project already meets ≥2 core components via Prompt Eng + RAG + Multimodal (+ Synthetic Data).

---

## 🧰 Requirements
- Python **3.10+**
- Install deps:  
  ```bash
  pip install -r requirements.txt
  ```

> FAISS is optional. If it cannot be installed on your platform, the notebook **falls back** to a NumPy inner‑product search and **sparse** retrieval still works.

Optional (if you want cloud generation): set provider keys as environment variables before starting Jupyter, e.g.:
```bash
export OPENAI_API_KEY=...
```

---

## 🚀 Quickstart (Run Order)
1. **Install** dependencies  
   ```bash
   pip install -r requirements.txt
   ```
2. **Add PDFs** to `pdfs/`
3. Open the notebook **“EduGen_All_in_One_MAX_RAG_UI_FULL (3).ipynb”** in Jupyter
4. **Build Knowledge Base** (KB) — run the KB build cell and confirm “Indexed chunks: …”
5. **Vector/Hybrid setup** — run cells labeled **Cell 1.1 → 1.5**
6. **Launch UI** — run the Gradio UI cell and try a question
7. **Concept Map** — run the concept‑map cell (saves `outputs/concept_map.png`)
8. **Web Export** — run the export cell, then the visuals/metrics patch cell
9. **Devset & Metrics** — run the evaluator; ensure `outputs/retrieval_metrics.json` is created
10. **Tests** — run the tests cell (pytest or the lightweight fallback)

**Recommended defaults**
```python
RETRIEVER_MODE = "hybrid"
HYBRID_ALPHA = 0.55
```

---

## 📊 Results (sample numbers from this submission)
**Devset size:** N = 10

| Retriever | Hit@1 | Hit@3 | Hit@5 | MRR  |
|-----------|:-----:|:-----:|:-----:|:----:|
| Sparse (BM25/TF‑IDF) | **0.90** | **1.00** | **1.00** | **0.95** |
| Hybrid (α = 0.55)    | 0.70 | 1.00 | 1.00 | 0.85 |
| Vector (MiniLM)      | 0.40 | 0.50 | 0.60 | 0.475 |

**Takeaways.** On a small, technical KB, **sparse retrieval** aligns closely with query wording and wins. **Hybrid** narrows the gap and is more robust to paraphrase. **Vector** can improve with stronger embeddings (e.g., `all-mpnet-base-v2`, `bge-small-en-v1.5`), a cross‑encoder reranker for top‑K, and slightly larger chunks with overlap.

Metrics are saved to `outputs/retrieval_metrics.json` and injected into the static page (`web/index.html`).

---

## 🌐 Web Page (GitHub Pages)
You can host the `web/` site using GitHub Pages:
1. Commit & push your repo
2. In **Settings → Pages**, set **Source: main branch** and **Folder: /root** or move `web/` to `docs/` and select `/docs`
3. Visit the Pages URL; you should see the latest output, **Visuals** (architecture + concept map), and the **Retrieval Metrics** table

---

## 🧪 Tests
Run tests (optional but recommended):
```bash
pytest -q
```
What they check:
- `web/index.html` and `web/assets/latest.json` exist and load
- Basic guardrail blocks known “prompt‑injection/secret” strings

---

## 📁 Project layout
```
.
├── EduGen_All_in_One_MAX_RAG_UI_FULL (3).ipynb
├── pdfs/
├── outputs/
│   ├── architecture.png
│   ├── concept_map.png
│   ├── devset.jsonl
│   └── retrieval_metrics.json
├── web/
│   ├── index.html
│   └── assets/
│       ├── latest.json
│       ├── architecture.png
│       └── concept_map.png
├── tests/
│   ├── test_export.py
│   └── test_guardrail.py
└── requirements.txt
```

---

## 🔒 Ethics & Safety
- Simple input/output **guardrails** to avoid obvious misuse (prompt injection, secret requests)
- Documents are local PDFs supplied by the user; respect copyright and cite sources in outputs
- Document limitations where the model may extrapolate beyond retrieved context

---

## ⚠️ Troubleshooting
- **FAISS install fails / M1 Mac:** set `RETRIEVER_MODE = "sparse"` or use **hybrid** with smaller α; the notebook will fall back automatically
- **No visuals on page:** re‑run the “add images to web page” patch; verify `web/assets/architecture.png` and `web/assets/concept_map.png`
- **Metrics table missing:** ensure `outputs/retrieval_metrics.json` exists, then re‑run the metrics‑injection cell
- **Empty retrieval:** increase Top‑K to 6–8 or switch to **hybrid**
